INSERT INTO project_manager(id, name, username, password, project_name) VALUES (1, 'Dheeraj Vishwakarma', 'dheeraj', 'dhee123', 'CDE_Project-1');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (2, 'Rohit Sahu', 'rohit', 'roh123', 'CDE_Project-2');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (3, 'Aditi Debnath', 'aditi', 'aditi123', 'CDE_Project-3');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (4, 'Antony Caleb', 'caleb', 'caleb123', 'CDE_Project-4');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (5, 'Madhav Agrawal', 'madhav', 'mad123', 'CDE_Project-5');